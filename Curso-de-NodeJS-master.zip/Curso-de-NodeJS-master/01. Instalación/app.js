process.stdout.write("dsdsd");


var nombre = "Marcos Rivas";

//console.log(`\n\nHello ${nombre}`);
var nombre = function saludo(){
	console.log("Holi");
};

nombre();

saludo();