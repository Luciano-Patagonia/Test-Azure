var path = require("path");
var a = 5;
var b = 10;


console.log(__dirname);
console.log(__filename);
console.log(path.basename(__filename));