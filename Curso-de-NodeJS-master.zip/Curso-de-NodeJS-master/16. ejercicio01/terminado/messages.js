const messages = {
    fileSaved: 'Archivo guardado, puedes seguir editando...',
    fileNotSaved : 'Archivo no guardado, puedes seguir editando...',
    requestFileName: '* Nombre del archivo: ',
    replaceFile: 'Deseas sustituir el archivo?(y/n): ',
    fileNotFound: 'El archivo no existe',
    fileExists: '*** Ya existe ese archivo! ***'
};

module.exports = messages;